<!DOCTYPE html>

<html>

<body>

Here is the Texture you have chosen  <?php echo $_POST["texture"]; ?> <br /> <br />

Here is the Sponge Size you have chosen  <?php echo $_POST["size"]; ?> <br /> <br />

<?php
if(isset($_POST['submit'])){
if(!empty($_POST['check_list'])) {
// Counting number of checked checkboxes.
$checked_count = count($_POST['check_list']);
echo "You have selected the following ".$checked_count." color(s): <br/>";
// Loop to store and display values of individual checked checkbox.
foreach($_POST['check_list'] as $selected) {
echo "<p>".$selected ."</p>";
}
}
}
?>


</body>
</html>